"""
═══════════════════════════════════════════════════════════════════════════
    MODULE DE CONNEXION À LA BASE DE DONNÉES - PROJET CINEFAN
═══════════════════════════════════════════════════════════════════════════
    
    Module minimal pour la connexion PostgreSQL
    Contient uniquement la fonction connect() qui retourne une connexion
    à la base de données cinefan
    
═══════════════════════════════════════════════════════════════════════════
"""

import psycopg2


# ═══════════════════════════════════════════════════════════════════════════
#                      FONCTION DE CONNEXION
# ═══════════════════════════════════════════════════════════════════════════

def connect():
    """
    Établit et renvoie une connexion à la base de données PostgreSQL '"cinefan"
    """
    conn = psycopg2.connect(
        dbname="",
        user="postgres",
        host="localhost",
        password="password",
    )
    return conn


# ═══════════════════════════════════════════════════════════════════════════
#                              FIN DU FICHIER
# ═══════════════════════════════════════════════════════════════════════════ 