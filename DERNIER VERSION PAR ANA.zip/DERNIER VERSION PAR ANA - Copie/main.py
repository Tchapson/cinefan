"""
═══════════════════════════════════════════════════════════════════════════
    APP WEB FLASK - PROJET CINEFAN
═══════════════════════════════════════════════════════════════════════════
    
    Application web pour gérer une collection d'oeuvres cinématographiques
    
    Routes principales:
    - /: page d'accueil avec statistiques
    - /oeuvres: liste de toutes les oeuvres
    - /oeuvre/<id>: détail d'une oeuvre
    - /recherche: recherche d'oeuvres
    - /connexion, /inscription: authentification
    
═══════════════════════════════════════════════════════════════════════════
"""

from flask import Flask, render_template, request, redirect, url_for, session, flash
#from datetime import date
import fonctions as fcts

app = Flask(__name__)
app.secret_key = "secretyyyy_key_projet"


# ═══════════════════════════════════════════════════════════════════════════
#                           ROUTES: ACCUEIL
# ═══════════════════════════════════════════════════════════════════════════
@app.route("/")
def accueil():
    """
    Page d'accueil: affiche des stats globales et les oeuvres récentes
    """
    nb_oeuvres = fcts.compter_lignes("oeuvre").c
    nb_artistes = fcts.compter_lignes("artiste").c
    nb_commentaires = fcts.compter_lignes("commentaire").c
    oeuvres_recent = fcts.get_oeuvres_recentes(6)

    return render_template(
        "accueil.html",
        nb_oeuvres=nb_oeuvres,
        nb_artistes=nb_artistes,
        nb_commentaires=nb_commentaires,
        oeuvres_recent=oeuvres_recent
    )


# ═══════════════════════════════════════════════════════════════════════════
#                           ROUTES: RECHERCHE
# ═══════════════════════════════════════════════════════════════════════════
@app.route("/recherche")
def recherche():
    """
    Recherche d'oeuvres par titre ou description
    Si pas de query, affiche la page vide
    """
    q = request.args.get("q", "")

    if q.strip() == "":
        return render_template("recherche.html", q="", resultats=[])

    resultats = fcts.rechercher_oeuvres(q)
    return render_template("recherche.html", q=q, resultats=resultats)


# ═══════════════════════════════════════════════════════════════════════════
#                      ROUTES: LISTE DES OEUVRES
# ═══════════════════════════════════════════════════════════════════════════
@app.route("/oeuvres")
def oeuvres():
    """Liste complète de toutes les oeuvres, triées par titre"""
    data = fcts.get_toutes_oeuvres()
    return render_template("oeuvres.html", oeuvres=data)


# ═══════════════════════════════════════════════════════════════════════════
#                      ROUTES: DÉTAIL D'UNE OEUVRE
# ═══════════════════════════════════════════════════════════════════════════
@app.route("/oeuvre/<int:id_oeuvre>")
def oeuvre_detail(id_oeuvre):
    """
    Page de détail d'une oeuvre: infos, genres, acteurs, réalisateurs,
    commentaires, liens vers autres oeuvres, statut favori
    """
    if not fcts.oeuvre_existe(id_oeuvre):
        return render_template("404.html"), 404
    
    oeuvre = fcts.get_oeuvre(id_oeuvre)
    genres = fcts.get_genres_oeuvre(id_oeuvre)
    realisateurs = fcts.get_realisateurs_oeuvre(id_oeuvre)
    acteurs = fcts.get_personnages_avec_acteurs(id_oeuvre)
    liens = fcts.get_liens_oeuvre(id_oeuvre)
    commentaires = fcts.get_commentaires_oeuvre(id_oeuvre)

    oeuvre_est_favori = False
    if session.get("user_id"):
        oeuvre_est_favori = fcts.est_favori(session["user_id"], id_oeuvre)

    return render_template(
        "oeuvre_detail.html",
        oeuvre=oeuvre,
        genres=genres,
        realisateurs=realisateurs,
        acteurs=acteurs,
        liens=liens,
        commentaires=commentaires,
        est_favori=oeuvre_est_favori
    )


# ═══════════════════════════════════════════════════════════════════════════
#                          GESTION DES FAVORIS
# ═══════════════════════════════════════════════════════════════════════════
@app.route("/favori/<int:id_oeuvre>", methods=["POST"])
def ajouter_favori(id_oeuvre):
    """
    Ajoute une oeuvre aux favoris de l'utilisateur connecté
    Redirige vers la connexion si pas connecté
    """
    if "user_id" not in session:
        return redirect(url_for("connexion"))
    
    try:
        fcts.ajouter_favori(session["user_id"], id_oeuvre)
        flash("Ajouté aux favoris", "success")
    except ValueError as e:
        flash(str(e), "error")
        session.clear()
        return redirect(url_for("connexion"))
    
    return redirect(url_for("oeuvre_detail", id_oeuvre=id_oeuvre))


# ═══════════════════════════════════════════════════════════════════════════
#                        GESTION DES COMMENTAIRES
# ═══════════════════════════════════════════════════════════════════════════
@app.route("/commentaire/<int:id_oeuvre>", methods=["POST"])
def ajouter_commentaire(id_oeuvre):
    """
    Ajoute un commentaire sur une oeuvre
    Valide la longueur (5-5000 caractères) et affiche un message flash
    """
    if "user_id" not in session:
        return redirect(url_for("connexion"))

    contenu = request.form.get("contenu")

    try:
        fcts.creer_commentaire(contenu, session["user_id"], id_oeuvre)
        flash("Commentaire ajouté :))", "success")
    except ValueError as e:
        flash(str(e), "error")

    return redirect(url_for("oeuvre_detail", id_oeuvre=id_oeuvre))


# ═══════════════════════════════════════════════════════════════════════════
#                      AUTHENTIFICATION: INSCRIPTION
# ═══════════════════════════════════════════════════════════════════════════
@app.route("/inscription", methods=["GET", "POST"])
def inscription():
    """
    Création d'un nouveau compte utilisateur
    Vérifie que l'email n'existe pas déjà
    """
    if request.method == "POST":
        pseudo = request.form.get("pseudo")
        email = request.form.get("email")
        mdp = request.form.get("mdp")

        if fcts.get_utilisateur_par_email(email):
            flash("Email déjà utilisé.", "error")
            return redirect(url_for("inscription"))

        fcts.creer_utilisateur(pseudo, email, mdp)
        flash("Compte créé avec succès !", "success")
        return redirect(url_for("connexion"))

    return render_template("inscription.html")


# ═══════════════════════════════════════════════════════════════════════════
#                       AUTHENTIFICATION: CONNEXION
# ═══════════════════════════════════════════════════════════════════════════
@app.route("/connexion", methods=["GET", "POST"])
def connexion():
    """
    Connexion utilisateur: vérifie email + mot de passe
    Bloque les comptes bannis et crée une session
    """
    if request.method == "POST":
        email = request.form.get("email")
        mdp = request.form.get("mdp")

        user = fcts.verifier_utilisateur(email, mdp)

        if not user:
            flash("Identifiants incorrects.", "error")
            return redirect(url_for("connexion"))

        if fcts.est_banni(user.id_utilisateur):
            flash("Le compte est banni!!;))))", "error")
            return redirect(url_for("connexion"))

        session["user_id"] = user.id_utilisateur
        session["pseudo"] = user.pseudo

        return redirect(url_for("accueil"))

    return render_template("connexion.html")


# ═══════════════════════════════════════════════════════════════════════════
#                      AUTHENTIFICATION : DÉCONNEXION
# ═══════════════════════════════════════════════════════════════════════════
@app.route("/deconnexion")
def deconnexion():
    """Déconnexion: efface toute la session et redirige vers l'accueil"""
    session.clear()
    return redirect(url_for("accueil"))


# ═══════════════════════════════════════════════════════════════════════════
#                      GESTION DES ERREURS & REDIRECTIONS
# ═══════════════════════════════════════════════════════════════════════════
@app.errorhandler(404)
def page_404(e):
    """Gestion des pages introuvables(404)"""
    return render_template("404.html"), 404


@app.route("/accueil")
def accueil_redirect():
    """Redirection /accueil → /"""
    return redirect(url_for("accueil"))


@app.route("/oeuvre/")
def oeuvre_redirect():
    """Redirection /oeuvre/ → /oeuvres"""
    return redirect(url_for("oeuvres"))


# ═══════════════════════════════════════════════════════════════════════════
#                          LANCEMENT DU SERVEUR
# ═══════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app.run(debug=True)
