DROP TABLE IF EXISTS realise CASCADE;
DROP TABLE IF EXISTS appartient CASCADE;
DROP TABLE IF EXISTS joue CASCADE;
DROP TABLE IF EXISTS lien CASCADE;
DROP TABLE IF EXISTS favoris CASCADE;
DROP TABLE IF EXISTS episode CASCADE;
DROP TABLE IF EXISTS photo CASCADE;
DROP TABLE IF EXISTS categorie CASCADE;
DROP TABLE IF EXISTS personnage CASCADE;
DROP TABLE IF EXISTS commentaire CASCADE;
DROP TABLE IF EXISTS artiste CASCADE;
DROP TABLE IF EXISTS oeuvre CASCADE;
DROP TABLE IF EXISTS utilisateur CASCADE;

DROP TABLE IF EXISTS realise;
DROP TABLE IF EXISTS appartient;
DROP TABLE IF EXISTS joue;
DROP TABLE IF EXISTS lien;
DROP TABLE IF EXISTS favoris;
DROP TABLE IF EXISTS episode;
DROP TABLE IF EXISTS photo;
DROP TABLE IF EXISTS categorie;
DROP TABLE IF EXISTS personnage;
DROP TABLE IF EXISTS commentaire;
DROP TABLE IF EXISTS artiste;
DROP TABLE IF EXISTS oeuvre;
DROP TABLE IF EXISTS utilisateur;

CREATE TABLE utilisateur(
    id_utilisateur serial PRIMARY KEY,
    pseudo varchar(50) NOT NULL,
    email varchar(50) UNIQUE NOT NULL,
    mdp text NOT NULL,
    role_utilisateur varchar(10) DEFAULT 'user'
);

CREATE TABLE oeuvre(
    id_oeuvre serial PRIMARY KEY,
    titre text NOT NULL,
    numero_volet_saison int,
    type_oeuvre varchar(50) NOT NULL,
    date_creation date NOT NULL,
    description_oeuvre text
);

CREATE TABLE artiste(
    id_artiste serial PRIMARY KEY,
    nom varchar(50) NOT NULL,
    prenom varchar(50) NOT NULL,
    date_naissance date NOT NULL,
    biographie text,
    UNIQUE(nom, prenom)
);

CREATE TABLE commentaire(
    id_commentaire serial PRIMARY KEY,
    contenu text NOT NULL,
    date_commentaire date NOT NULL,
    id_utilisateur int REFERENCES utilisateur(id_utilisateur),
    id_oeuvre int REFERENCES oeuvre(id_oeuvre)
);

CREATE TABLE personnage(
    id_personnage serial PRIMARY KEY,
    libelle varchar(50) NOT NULL
);

CREATE TABLE categorie(
    nom_cat varchar(50) PRIMARY KEY
);

CREATE TABLE photo(
    id_photo serial PRIMARY KEY,
    chemin varchar(200) NOT NULL,
    description_ text,
    id_utilisateur int REFERENCES utilisateur(id_utilisateur),
    id_oeuvre int REFERENCES oeuvre(id_oeuvre)
);

CREATE TABLE episode(
    id_episode serial PRIMARY KEY,
    titre text NOT NULL,
    num_ep varchar(100),
    synopsie text,
    id_oeuvre int REFERENCES oeuvre(id_oeuvre)
);

CREATE TABLE favoris(
    id_utilisateur int REFERENCES utilisateur(id_utilisateur),
    id_oeuvre int REFERENCES oeuvre(id_oeuvre),
    date_ajout date NOT NULL,
    PRIMARY KEY(id_utilisateur, id_oeuvre)
);

CREATE TABLE lien(
    id_oeuvre1 int REFERENCES oeuvre(id_oeuvre),
    id_oeuvre2 int REFERENCES oeuvre(id_oeuvre),
    type_lien varchar(20) NOT NULL,
    PRIMARY KEY (id_oeuvre1, id_oeuvre2)
);

CREATE TABLE joue(
    id_artiste int REFERENCES artiste(id_artiste),
    id_oeuvre int REFERENCES oeuvre(id_oeuvre),
    id_personnage int REFERENCES personnage(id_personnage),
    PRIMARY KEY (id_artiste, id_oeuvre, id_personnage)
);

CREATE TABLE appartient(
    id_oeuvre int REFERENCES oeuvre(id_oeuvre),
    nom_cat varchar(50) REFERENCES categorie(nom_cat),
    PRIMARY KEY(id_oeuvre, nom_cat)
);

CREATE TABLE realise(
    id_artiste int REFERENCES artiste(id_artiste),
    id_oeuvre int REFERENCES oeuvre(id_oeuvre),
    PRIMARY KEY (id_artiste, id_oeuvre)
);

------------------- VUES ------------------

CREATE VIEW NbFilmsGenreParActeur AS (
    SELECT artiste.id_artiste,
           artiste.nom,
           artiste.prenom,
           appartient.nom_cat,
           COUNT(*) AS nb_films
    FROM joue
    JOIN oeuvre ON oeuvre.id_oeuvre = joue.id_oeuvre
    JOIN appartient ON appartient.id_oeuvre = oeuvre.id_oeuvre
    JOIN artiste ON joue.id_artiste = artiste.id_artiste
    GROUP BY artiste.id_artiste, artiste.nom, artiste.prenom, appartient.nom_cat
    ORDER BY nb_films DESC
);

CREATE VIEW NbCrtiquesUtilisateur AS (
    SELECT utilisateur.id_utilisateur,
           utilisateur.pseudo,
           COUNT(id_commentaire) AS nb_commentaires
    FROM utilisateur
    LEFT JOIN commentaire ON utilisateur.id_utilisateur = commentaire.id_utilisateur
    GROUP BY utilisateur.id_utilisateur, pseudo
);

CREATE VIEW NbCrtiquesMoyParGenre AS (
    SELECT c.nom_cat AS genre,
           COUNT(co.id_commentaire) * 1.0 /
                (SELECT COUNT(*) FROM utilisateur) AS moyenne_par_utilisateur
    FROM commentaire co
    JOIN oeuvre o ON co.id_oeuvre = o.id_oeuvre
    JOIN appartient ap ON o.id_oeuvre = ap.id_oeuvre
    JOIN categorie c ON ap.nom_cat = c.nom_cat
    GROUP BY c.nom_cat
);

----------------- REMPLISSAGE TABLES --------------------

-- ═══════════════════════════════════════════════════════════
--                        UTILISATEURS
-- ═══════════════════════════════════════════════════════════

INSERT INTO utilisateur (pseudo, email, mdp, role_utilisateur) VALUES
('LukeFan', 'luke@mail.com', 'skyw000', 'user'),
('WinterIsComing', 'snow@mail.com', 'sword987', 'user'),
('AdminBoss', 'admin@mail.com', 'admin007', 'admin'),
('MarvelAddict', 'marvel@mail.com', 'avngrs42', 'user'),
('CineCritique', 'critique@mail.com', 'review99', 'user'),
('MovieBuff2024', 'moviebuff@mail.com', 'cinema456', 'user'),
('FilmNoir_Lover', 'noirfan@mail.com', 'darkness12', 'user'),
('SeriesAddict', 'series@mail.com', 'binge789', 'user'),
('SciFiGeek', 'scifi@mail.com', 'space999', 'user'),
('HorrorFanatic', 'horror@mail.com', 'scary666', 'user'),
('RomComQueen', 'romcom@mail.com', 'love123', 'user'),
('ActionHero', 'action@mail.com', 'boom777', 'user'),
('ThrillerFan', 'thriller@mail.com', 'suspense55', 'user'),
('AnimeLover', 'anime@mail.com', 'manga888', 'user'),
('ClassicCinema', 'classic@mail.com', 'oldies44', 'user'),
('DocumentaryFan', 'docus@mail.com', 'facts321', 'user'),
('IndieSupporter', 'indie@mail.com', 'arthouse99', 'user'),
('ComedyKing', 'comedy@mail.com', 'lol555', 'user'),
('DramaQueen', 'drama@mail.com', 'tears222', 'user'),
('FantasyDreamer', 'fantasy@mail.com', 'magic111', 'user');

-- ═══════════════════════════════════════════════════════════
--                         ARTISTES
-- ═══════════════════════════════════════════════════════════

INSERT INTO artiste (nom, prenom, date_naissance, biographie) VALUES
('DiCaprio', 'Leonardo', '1974-11-11', 'Acteur américain, Inception, Titanic'),
('Portman', 'Natalie', '1981-06-09', 'Actrice, Star Wars, Black Swan'),
('Ford', 'Harrison', '1942-07-13', 'Acteur, Han Solo, Indiana Jones'),
('Hamill', 'Mark', '1951-09-25', 'Acteur, Luke Skywalker'),
('Harington', 'Kit', '1986-12-26', 'Acteur, Jon Snow dans Game of Thrones'),
('Nolan', 'Christopher', '1970-07-30', 'Réalisateur britannique, Inception, The Dark Knight'),
('Tarantino', 'Quentin', '1963-03-27', 'Réalisateur américain, Pulp Fiction, Django'),
('Scorsese', 'Martin', '1942-11-17', 'Réalisateur américain, Goodfellas, The Wolf of Wall Street'),
('Fincher', 'David', '1962-08-28', 'Réalisateur américain, Fight Club, Seven'),
('Villeneuve', 'Denis', '1967-10-03', 'Réalisateur canadien, Dune, Blade Runner 2049'),
('Cruise', 'Tom', '1962-07-03', 'Acteur américain, Mission Impossible, Top Gun'),
('Pitt', 'Brad', '1963-12-18', 'Acteur américain, Fight Club, Once Upon a Time'),
('Johansson', 'Scarlett', '1984-11-22', 'Actrice américaine, Avengers, Lost in Translation'),
('Downey Jr', 'Robert', '1965-04-04', 'Acteur américain, Iron Man, Sherlock Holmes'),
('Hemsworth', 'Chris', '1983-08-11', 'Acteur australien, Thor, Avengers'),
('Robbie', 'Margot', '1990-07-02', 'Actrice australienne, Barbie, Suicide Squad'),
('Gosling', 'Ryan', '1980-11-12', 'Acteur canadien, Blade Runner 2049, La La Land'),
('Stone', 'Emma', '1988-11-06', 'Actrice américaine, La La Land, Poor Things'),
('Phoenix', 'Joaquin', '1974-10-28', 'Acteur américain, Joker, Her'),
('Blanchett', 'Cate', '1969-05-14', 'Actrice australienne, Lord of the Rings, Blue Jasmine'),
('Washington', 'Denzel', '1954-12-28', 'Acteur américain, Training Day, Malcolm X'),
('Freeman', 'Morgan', '1937-06-01', 'Acteur américain, Shawshank Redemption, Se7en'),
('Hanks', 'Tom', '1956-07-09', 'Acteur américain, Forrest Gump, Cast Away'),
('Streep', 'Meryl', '1949-06-22', 'Actrice américaine, The Devil Wears Prada, Sophie Choice'),
('Dench', 'Judi', '1934-12-09', 'Actrice britannique, James Bond, Shakespeare in Love'),
('Hopkins', 'Anthony', '1937-12-31', 'Acteur britannique, Silence of the Lambs, The Father'),
('Bale', 'Christian', '1974-01-30', 'Acteur britannique, Batman, The Machinist'),
('Hardy', 'Tom', '1977-09-15', 'Acteur britannique, Mad Max, Inception'),
('Hathaway', 'Anne', '1982-11-12', 'Actrice américaine, Les Misérables, Interstellar'),
('Chalamet', 'Timothée', '1995-12-27', 'Acteur américain, Dune, Call Me By Your Name'),
('Zendaya', 'Maree', '1996-09-01', 'Actrice américaine, Euphoria, Dune'),
('Pugh', 'Florence', '1996-01-03', 'Actrice britannique, Little Women, Black Widow'),
('Driver', 'Adam', '1983-11-19', 'Acteur américain, Star Wars, Marriage Story'),
('Isaac', 'Oscar', '1979-03-09', 'Acteur américain, Dune, Ex Machina'),
('Murphy', 'Cillian', '1976-05-25', 'Acteur irlandais, Oppenheimer, Peaky Blinders'),
('Jackson', 'Samuel L.', '1948-12-21', 'Acteur américain, Pulp Fiction, Avengers'),
('Keaton', 'Michael', '1951-09-05', 'Acteur américain, Batman, Birdman'),
('Neeson', 'Liam', '1952-06-07', 'Acteur irlandais, Taken, Schindler List'),
('Willis', 'Bruce', '1955-03-19', 'Acteur américain, Die Hard, Pulp Fiction'),
('Reeves', 'Keanu', '1964-09-02', 'Acteur canadien, Matrix, John Wick');

-- ═══════════════════════════════════════════════════════════
--                         OEUVRES
-- ═══════════════════════════════════════════════════════════

INSERT INTO oeuvre (titre, numero_volet_saison, type_oeuvre, date_creation, description_oeuvre) VALUES
('Inception', NULL, 'film', '2010-07-16', 'Film de science-fiction de Christopher Nolan'),
('Star Wars', 4, 'film', '1977-05-25', 'Episode IV : Un Nouvel Espoir'),
('Star Wars', 5, 'film', '1980-05-21', 'Episode V : L Empire contre-attaque'),
('Star Wars', 6, 'film', '1983-05-25', 'Episode VI : Le Retour du Jedi'),
('Game of Thrones', 1, 'série', '2011-04-17', 'Saison 1 de la série HBO'),
('Game of Thrones', 2, 'série', '2012-04-01', 'Saison 2 de la série HBO'),
('The Dark Knight', NULL, 'film', '2008-07-18', 'Batman affronte le Joker dans Gotham City'),
('Pulp Fiction', NULL, 'film', '1994-10-14', 'Film culte de Quentin Tarantino'),
('Fight Club', NULL, 'film', '1999-10-15', 'Un homme découvre un club de combat clandestin'),
('The Matrix', NULL, 'film', '1999-03-31', 'Neo découvre la vérité sur la réalité'),
('Interstellar', NULL, 'film', '2014-11-07', 'Voyage spatial pour sauver l humanité'),
('The Shawshank Redemption', NULL, 'film', '1994-09-23', 'Histoire d amitié en prison'),
('Forrest Gump', NULL, 'film', '1994-07-06', 'Parcours extraordinaire d un homme simple'),
('The Godfather', NULL, 'film', '1972-03-24', 'Saga mafieuse de la famille Corleone'),
('Goodfellas', NULL, 'film', '1990-09-19', 'Ascension et chute d un gangster'),
('Se7en', NULL, 'film', '1995-09-22', 'Enquête sur un tueur en série inspiré des 7 péchés'),
('The Silence of the Lambs', NULL, 'film', '1991-02-14', 'Agent FBI consulte Hannibal Lecter'),
('Blade Runner 2049', NULL, 'film', '2017-10-06', 'Suite du classique de science-fiction'),
('Dune', 1, 'film', '2021-10-22', 'Première partie de l adaptation du roman'),
('Dune', 2, 'film', '2024-03-01', 'Suite de l épopée sur Arrakis'),
('Avengers: Endgame', NULL, 'film', '2019-04-26', 'Bataille finale contre Thanos'),
('Avengers: Infinity War', NULL, 'film', '2018-04-27', 'Les Avengers face à Thanos'),
('Iron Man', NULL, 'film', '2008-05-02', 'Tony Stark devient Iron Man'),
('Thor', NULL, 'film', '2011-05-06', 'Le dieu du tonnerre banni sur Terre'),
('Barbie', NULL, 'film', '2023-07-21', 'Barbie découvre le monde réel'),
('Oppenheimer', NULL, 'film', '2023-07-21', 'Biographie du père de la bombe atomique'),
('The Wolf of Wall Street', NULL, 'film', '2013-12-25', 'Ascension d un courtier corrompu'),
('Titanic', NULL, 'film', '1997-12-19', 'Romance tragique sur le Titanic'),
('The Lord of the Rings', 1, 'film', '2001-12-19', 'La Communauté de l Anneau'),
('The Lord of the Rings', 2, 'film', '2002-12-18', 'Les Deux Tours'),
('The Lord of the Rings', 3, 'film', '2003-12-17', 'Le Retour du Roi'),
('Breaking Bad', 1, 'série', '2008-01-20', 'Prof de chimie devient fabricant de meth'),
('Breaking Bad', 2, 'série', '2009-03-08', 'Walter White s enfonce dans le crime'),
('Breaking Bad', 3, 'série', '2010-03-21', 'Tensions avec Gus Fring'),
('Breaking Bad', 4, 'série', '2011-07-17', 'Confrontation avec Gus'),
('Breaking Bad', 5, 'série', '2012-07-15', 'Saison finale épique'),
('Stranger Things', 1, 'série', '2016-07-15', 'Disparition mystérieuse dans une petite ville'),
('Stranger Things', 2, 'série', '2017-10-27', 'Le retour de l Upside Down'),
('Stranger Things', 3, 'série', '2019-07-04', 'Été 1985 à Hawkins'),
('Stranger Things', 4, 'série', '2022-05-27', 'Face à Vecna'),
('The Mandalorian', 1, 'série', '2019-11-12', 'Chasseur de primes et Baby Yoda'),
('The Mandalorian', 2, 'série', '2020-10-30', 'Aventures continues dans Star Wars'),
('The Crown', 1, 'série', '2016-11-04', 'Règne d Elizabeth II'),
('The Crown', 2, 'série', '2017-12-08', 'Années 1960'),
('Peaky Blinders', 1, 'série', '2013-09-12', 'Gang de Birmingham après WWI'),
('Peaky Blinders', 2, 'série', '2014-10-02', 'Expansion du gang Shelby'),
('The Witcher', 1, 'série', '2019-12-20', 'Geralt de Riv chasseur de monstres'),
('The Witcher', 2, 'série', '2021-12-17', 'Quête de Ciri'),
('House of the Dragon', 1, 'série', '2022-08-21', 'Préquelle de Game of Thrones'),
('House of the Dragon', 2, 'série', '2024-06-16', 'Guerre civile Targaryen');

-- ═══════════════════════════════════════════════════════════
--                        CATÉGORIES
-- ═══════════════════════════════════════════════════════════

INSERT INTO categorie VALUES
('Science-Fiction'),
('Fantastique'),
('Drame'),
('Aventure'),
('Action'),
('Thriller'),
('Crime'),
('Comédie'),
('Romance'),
('Horreur'),
('Animation'),
('Documentaire'),
('Guerre'),
('Historique'),
('Biographie'),
('Musical'),
('Western'),
('Mystère');

-- ═══════════════════════════════════════════════════════════
--                    GENRES DES OEUVRES
-- ═══════════════════════════════════════════════════════════

INSERT INTO appartient VALUES
-- Inception
(1, 'Science-Fiction'),
(1, 'Thriller'),
(1, 'Action'),
-- Star Wars
(2, 'Science-Fiction'),
(2, 'Aventure'),
(3, 'Science-Fiction'),
(3, 'Aventure'),
(4, 'Science-Fiction'),
(4, 'Aventure'),
-- Game of Thrones
(5, 'Fantastique'),
(5, 'Drame'),
(5, 'Aventure'),
(6, 'Fantastique'),
(6, 'Drame'),
-- The Dark Knight
(7, 'Action'),
(7, 'Crime'),
(7, 'Thriller'),
-- Pulp Fiction
(8, 'Crime'),
(8, 'Thriller'),
(8, 'Drame'),
-- Fight Club
(9, 'Drame'),
(9, 'Thriller'),
-- The Matrix
(10, 'Science-Fiction'),
(10, 'Action'),
-- Interstellar
(11, 'Science-Fiction'),
(11, 'Drame'),
(11, 'Aventure'),
-- Shawshank
(12, 'Drame'),
-- Forrest Gump
(13, 'Drame'),
(13, 'Romance'),
-- The Godfather
(14, 'Crime'),
(14, 'Drame'),
-- Goodfellas
(15, 'Crime'),
(15, 'Drame'),
(15, 'Biographie'),
-- Se7en
(16, 'Crime'),
(16, 'Thriller'),
(16, 'Mystère'),
-- Silence of the Lambs
(17, 'Crime'),
(17, 'Thriller'),
(17, 'Horreur'),
-- Blade Runner 2049
(18, 'Science-Fiction'),
(18, 'Thriller'),
-- Dune
(19, 'Science-Fiction'),
(19, 'Aventure'),
(20, 'Science-Fiction'),
(20, 'Aventure'),
-- Avengers
(21, 'Action'),
(21, 'Science-Fiction'),
(21, 'Aventure'),
(22, 'Action'),
(22, 'Science-Fiction'),
(22, 'Aventure'),
(23, 'Action'),
(23, 'Science-Fiction'),
(24, 'Action'),
(24, 'Fantastique'),
(24, 'Aventure'),
-- Barbie
(25, 'Comédie'),
(25, 'Aventure'),
-- Oppenheimer
(26, 'Biographie'),
(26, 'Drame'),
(26, 'Historique'),
-- Wolf of Wall Street
(27, 'Biographie'),
(27, 'Crime'),
(27, 'Comédie'),
-- Titanic
(28, 'Romance'),
(28, 'Drame'),
-- LOTR
(29, 'Fantastique'),
(29, 'Aventure'),
(30, 'Fantastique'),
(30, 'Aventure'),
(31, 'Fantastique'),
(31, 'Aventure'),
-- Breaking Bad
(32, 'Crime'),
(32, 'Drame'),
(32, 'Thriller'),
(33, 'Crime'),
(33, 'Drame'),
(34, 'Crime'),
(34, 'Drame'),
(35, 'Crime'),
(35, 'Drame'),
(36, 'Crime'),
(36, 'Drame'),
-- Stranger Things
(37, 'Science-Fiction'),
(37, 'Horreur'),
(37, 'Mystère'),
(38, 'Science-Fiction'),
(38, 'Horreur'),
(39, 'Science-Fiction'),
(39, 'Horreur'),
(40, 'Science-Fiction'),
(40, 'Horreur'),
-- Mandalorian
(41, 'Science-Fiction'),
(41, 'Aventure'),
(42, 'Science-Fiction'),
(42, 'Aventure'),
-- The Crown
(43, 'Drame'),
(43, 'Historique'),
(44, 'Drame'),
(44, 'Historique'),
-- Peaky Blinders
(45, 'Crime'),
(45, 'Drame'),
(46, 'Crime'),
(46, 'Drame'),
-- The Witcher
(47, 'Fantastique'),
(47, 'Aventure'),
(48, 'Fantastique'),
(48, 'Aventure'),
-- House of the Dragon
(49, 'Fantastique'),
(49, 'Drame'),
(49, 'Aventure'),
(50, 'Fantastique'),
(50, 'Drame');

-- ═══════════════════════════════════════════════════════════
--                       PERSONNAGES
-- ═══════════════════════════════════════════════════════════

INSERT INTO personnage (libelle) VALUES
('Dom Cobb'),
('Luke Skywalker'),
('Han Solo'),
('Princess Leia'),
('Jon Snow'),
('Daenerys Targaryen'),
('Tyrion Lannister'),
('Bruce Wayne / Batman'),
('Joker'),
('Vincent Vega'),
('Jules Winnfield'),
('Tyler Durden'),
('Neo'),
('Trinity'),
('Morpheus'),
('Cooper'),
('Andy Dufresne'),
('Red'),
('Forrest Gump'),
('Vito Corleone'),
('Michael Corleone'),
('Henry Hill'),
('Detective Mills'),
('Detective Somerset'),
('Clarice Starling'),
('Hannibal Lecter'),
('Officer K'),
('Paul Atreides'),
('Lady Jessica'),
('Chani'),
('Tony Stark / Iron Man'),
('Thor'),
('Natasha Romanoff / Black Widow'),
('Steve Rogers / Captain America'),
('Barbie'),
('Ken'),
('J. Robert Oppenheimer'),
('Jordan Belfort'),
('Jack Dawson'),
('Rose DeWitt Bukater'),
('Frodo Baggins'),
('Gandalf'),
('Aragorn'),
('Walter White'),
('Jesse Pinkman'),
('Eleven'),
('Mike Wheeler'),
('Dustin Henderson'),
('Din Djarin / The Mandalorian'),
('Grogu'),
('Queen Elizabeth II'),
('Thomas Shelby'),
('Arthur Shelby'),
('Geralt of Rivia'),
('Yennefer'),
('Ciri'),
('Rhaenyra Targaryen'),
('Daemon Targaryen');

-- ═══════════════════════════════════════════════════════════
--            ACTEURS JOUENT DES PERSONNAGES
-- ═══════════════════════════════════════════════════════════

INSERT INTO joue VALUES
-- Inception (1)
(1, 1, 1),   -- DiCaprio joue Dom Cobb
(28, 1, 16), -- Tom Hardy joue un personnage dans Inception
-- Star Wars
(4, 2, 2),   -- Mark Hamill — Luke Skywalker — Star Wars IV
(3, 2, 3),   -- Harrison Ford — Han Solo — Star Wars IV
(2, 2, 4),   -- Natalie Portman — Princess Leia
(4, 3, 2),   -- Mark Hamill — Luke — Star Wars V
(3, 3, 3),   -- Harrison Ford — Han Solo — Star Wars V
(4, 4, 2),   -- Mark Hamill — Luke — Star Wars VI
(3, 4, 3),   -- Harrison Ford — Han Solo — Star Wars VI
-- Game of Thrones
(5, 5, 5),   -- Kit Harington — Jon Snow — GoT S1
(5, 6, 5),   -- Kit Harington — Jon Snow — GoT S2
-- The Dark Knight (7)
(27, 7, 8),  -- Christian Bale — Batman
(19, 7, 9),  -- Joaquin Phoenix comme Joker (hypothétique)
-- Pulp Fiction (8)
(11, 8, 10), -- Tom Cruise — Vincent Vega (hypothétique)
(36, 8, 11), -- Samuel L. Jackson — Jules Winnfield
(39, 8, 11), -- Bruce Willis dans Pulp Fiction
-- Fight Club (9)
(12, 9, 12), -- Brad Pitt — Tyler Durden
-- The Matrix (10)
(40, 10, 13), -- Keanu Reeves — Neo
-- Interstellar (11)
(29, 11, 16), -- Anne Hathaway — Cooper
-- Shawshank (12)
(22, 12, 17), -- Morgan Freeman — Red
-- Forrest Gump (13)
(23, 13, 19), -- Tom Hanks — Forrest Gump
-- The Godfather (14)
(26, 14, 20), -- Anthony Hopkins — Vito (hypothétique)
-- Goodfellas (15)
(21, 15, 22), -- Denzel Washington — Henry Hill (hypothétique)
-- Se7en (16)
(22, 16, 24), -- Morgan Freeman — Somerset
(12, 16, 23), -- Brad Pitt — Mills
-- Silence of the Lambs (17)
(26, 17, 26), -- Anthony Hopkins — Hannibal Lecter
-- Blade Runner 2049 (18)
(17, 18, 27), -- Ryan Gosling — Officer K
-- Dune (19, 20)
(30, 19, 28), -- Timothée Chalamet — Paul Atreides
(31, 19, 30), -- Zendaya — Chani
(30, 20, 28), -- Timothée Chalamet — Paul Atreides
(31, 20, 30), -- Zendaya — Chani
(34, 19, 29), -- Oscar Isaac — Duke Leto
-- Avengers (21, 22, 23)
(14, 21, 31), -- Robert Downey Jr — Iron Man
(15, 21, 32), -- Chris Hemsworth — Thor
(13, 21, 33), -- Scarlett Johansson — Black Widow
(14, 22, 31), -- Robert Downey Jr — Iron Man
(15, 22, 32), -- Chris Hemsworth — Thor
(14, 23, 31), -- Robert Downey Jr — Iron Man
-- Thor (24)
(15, 24, 32), -- Chris Hemsworth — Thor
-- Barbie (25)
(16, 25, 35), -- Margot Robbie — Barbie
(17, 25, 36), -- Ryan Gosling — Ken
-- Oppenheimer (26)
(35, 26, 37), -- Cillian Murphy — Oppenheimer
-- Wolf of Wall Street (27)
(1, 27, 38),  -- DiCaprio — Jordan Belfort
-- Titanic (28)
(1, 28, 39),  -- DiCaprio — Jack
-- Breaking Bad (32-36)
(35, 32, 44), -- Cillian Murphy — Walter White (hypothétique)
(35, 33, 44),
(35, 34, 44),
(35, 35, 44),
(35, 36, 44),
-- Peaky Blinders (45-46)
(35, 45, 52), -- Cillian Murphy — Thomas Shelby
(35, 46, 52);

-- ═══════════════════════════════════════════════════════════
--                       RÉALISATEURS
-- ═══════════════════════════════════════════════════════════

INSERT INTO realise VALUES
(6, 1),   -- Nolan — Inception
(6, 7),   -- Nolan — Dark Knight
(6, 11),  -- Nolan — Interstellar
(7, 8),   -- Tarantino — Pulp Fiction
(8, 15),  -- Scorsese — Goodfellas
(8, 27),  -- Scorsese — Wolf of Wall Street
(9, 9),   -- Fincher — Fight Club
(9, 16),  -- Fincher — Se7en
(10, 18), -- Villeneuve — Blade Runner 2049
(10, 19), -- Villeneuve — Dune 1
(10, 20); -- Villeneuve — Dune 2

-- ═══════════════════════════════════════════════════════════
--                       COMMENTAIRES
-- ═══════════════════════════════════════════════════════════

INSERT INTO commentaire (contenu, date_commentaire, id_utilisateur, id_oeuvre) VALUES
-- Inception
('Chef-d''oeuvre absolu', '2024-01-12', 1, 1),
('Effets spéciaux incroyables', '2024-01-13', 2, 1),
('Christopher Nolan au sommet de son art', '2024-01-14', 3, 1),
('Scénario brillant et complexe', '2024-01-15', 4, 1),
('Meilleur film de science-fiction de la décennie', '2024-01-16', 5, 1),
-- Star Wars
('Film culte, indétrônable', '2024-01-14', 3, 2),
('La Force est puissante avec celui-ci', '2024-01-17', 6, 2),
('Une saga intemporelle', '2024-01-18', 7, 2),
('Meilleur épisode de la trilogie originale!', '2024-01-14', 1, 3),
('L''Empire contre-attaque reste le meilleur', '2024-01-19', 8, 3),
('Vader est incroyable', '2024-01-20', 9, 3),
('Belle conclusion de la trilogie', '2024-01-21', 10, 4),
-- Game of Thrones
('Une saison captivante', '2024-01-15', 2, 5),
('Les Stark sont mes préférés', '2024-01-22', 11, 5),
('L''intrigue politique est fascinante', '2024-01-23', 12, 5),
('La bataille finale est incroyable', '2024-01-16', 4, 6),
('Très bon développement de Jon Snow', '2024-01-16', 5, 6),
('Tyrion vole la vedette', '2024-01-24', 13, 6),
-- The Dark Knight
('Le meilleur film de super-héros jamais réalisé', '2024-01-25', 14, 7),
('Heath Ledger est légendaire en Joker', '2024-01-26', 15, 7),
('Un chef-d''oeuvre du genre', '2024-01-27', 16, 7),
('Christian Bale parfait en Batman', '2024-01-28', 17, 7),
-- Pulp Fiction
('Dialogue incroyable de Tarantino', '2024-01-29', 18, 8),
('Film culte absolu', '2024-01-30', 19, 8),
('La bande-son est légendaire', '2024-02-01', 20, 8),
('Structure narrative brillante', '2024-02-02', 1, 8),
-- Fight Club
('Twist final incroyable', '2024-02-03', 2, 9),
('Brad Pitt au top', '2024-02-04', 3, 9),
('Un film qui marque les esprits', '2024-02-05', 4, 9),
-- The Matrix
('Révolutionnaire pour son époque', '2024-02-06', 5, 10),
('Les effets spéciaux sont incroyables', '2024-02-07', 6, 10),
('Keanu Reeves parfait en Neo', '2024-02-08', 7, 10),
('La pilule rouge ou la pilule bleue?', '2024-02-09', 8, 10),
-- Interstellar
('Visuellement époustouflant', '2024-02-10', 9, 11),
('La science-fiction à son meilleur', '2024-02-11', 10, 11),
('Musique de Hans Zimmer transcendante', '2024-02-12', 11, 11),
('Matthew McConaughey excellent', '2024-02-13', 12, 11),
-- Shawshank
('Le meilleur film de tous les temps', '2024-02-14', 13, 12),
('Une histoire d''amitié touchante', '2024-02-15', 14, 12),
('Morgan Freeman est parfait', '2024-02-16', 15, 12),
-- Forrest Gump
('Tom Hanks au sommet', '2024-02-17', 16, 13),
('Une histoire touchante', '2024-02-18', 17, 13),
('La vie est comme une boîte de chocolats', '2024-02-19', 18, 13),
-- The Godfather
('Le parrain de tous les films', '2024-02-20', 19, 14),
('Une saga familiale épique', '2024-02-21', 20, 14),
-- Goodfellas
('Scorsese au top', '2024-02-22', 1, 15),
('Ray Liotta incroyable', '2024-02-23', 2, 15),
-- Se7en
('Thriller sombre et captivant', '2024-02-24', 3, 16),
('La fin est choquante', '2024-02-25', 4, 16),
('Brad Pitt et Morgan Freeman : duo parfait', '2024-02-26', 5, 16),
-- Blade Runner 2049
('Suite digne de l''original', '2024-02-27', 6, 18),
('Visuellement magnifique', '2024-02-28', 7, 18),
('Ryan Gosling excellent', '2024-03-01', 8, 18),
-- Dune
('Adaptation fidèle et spectaculaire', '2024-03-02', 9, 19),
('Timothée Chalamet parfait en Paul', '2024-03-03', 10, 19),
('Visuellement époustouflant', '2024-03-04', 11, 19),
('Hans Zimmer encore une fois excellent', '2024-03-05', 12, 19),
('Meilleure que la première partie', '2024-03-06', 13, 20),
('Zendaya brille dans ce volet', '2024-03-07', 14, 20),
-- Avengers
('La conclusion parfaite de la saga Infinity', '2024-03-08', 15, 21),
('Tous les héros réunis, incroyable!', '2024-03-09', 16, 21),
('J''ai pleuré à la fin', '2024-03-10', 17, 21),
('Thanos est le meilleur méchant Marvel', '2024-03-11', 18, 22),
('Premier film MCU, le début d''une ère', '2024-03-12', 19, 23),
('Robert Downey Jr parfait en Tony Stark', '2024-03-13', 20, 23),
-- Barbie
('Film surprise de l''année 2023', '2024-03-14', 1, 25),
('Margot Robbie est parfaite', '2024-03-15', 2, 25),
('Ryan Gosling hilarant en Ken', '2024-03-16', 3, 25),
-- Oppenheimer
('Christopher Nolan encore une fois brillant', '2024-03-17', 4, 26),
('Cillian Murphy mérite l''Oscar', '2024-03-18', 5, 26),
('Film intense du début à la fin', '2024-03-19', 6, 26),
-- Breaking Bad
('Meilleure série de tous les temps', '2024-03-20', 7, 32),
('Walter White : personnage complexe fascinant', '2024-03-21', 8, 32),
('Bryan Cranston incroyable', '2024-03-22', 9, 33),
('La tension monte d''épisode en épisode', '2024-03-23', 10, 34),
('Gus Fring : méchant terrifiant', '2024-03-24', 11, 35),
('Finale parfaite', '2024-03-25', 12, 36),
-- Stranger Things
('Nostalgie des années 80', '2024-03-26', 13, 37),
('Eleven est un personnage génial', '2024-03-27', 14, 37),
('L''Upside Down me fait peur', '2024-03-28', 15, 38),
('Saison 3 : été 1985 parfait', '2024-03-29', 16, 39),
('Vecna est terrifiant', '2024-03-30', 17, 40),
-- Mandalorian
('Baby Yoda est adorable', '2024-04-01', 18, 41),
('Star Wars de retour en force', '2024-04-02', 19, 41),
('Pedro Pascal excellent', '2024-04-03', 20, 42),
-- Peaky Blinders
('Cillian Murphy hypnotisant', '2024-04-04', 1, 45),
('Thomas Shelby : personnage charismatique', '2024-04-05', 2, 45),
('L''ambiance des années 20 est parfaite', '2024-04-06', 3, 46),
-- House of the Dragon
('Digne successeur de Game of Thrones', '2024-04-07', 4, 49),
('Les dragons sont magnifiques', '2024-04-08', 5, 49),
('Guerre civile Targaryen captivante', '2024-04-09', 6, 50);

-- ═══════════════════════════════════════════════════════════
--                         PHOTOS
-- ═══════════════════════════════════════════════════════════

INSERT INTO photo (chemin, description_, id_utilisateur, id_oeuvre) VALUES
('/static/images/photo_1.jpeg', 'Affiche officielle', 1, 1),
('/static/images/photo_2.jpeg', 'Poster original Star Wars IV', 3, 2),
('/static/images/photo_3.jpg', 'Affiche saison 1', 2, 5),
('/static/images/photo_4.jpg', 'Batman face au Joker', 5, 7),
('/static/images/photo_5.jpg', 'Affiche culte Tarantino', 7, 8),
('/static/images/photo_6.jpg', 'Neo et la pilule rouge', 9, 10),
('/static/images/photo_7.jpg', 'Voyage spatial', 11, 11),
('/static/images/photo_8.jpg', 'Paul Atreides sur Arrakis', 13, 19),
('/static/images/photo_9.jpg', 'Tous les héros réunis', 15, 21),
('/static/images/photo_10.jpg', 'Barbie et Ken', 17, 25),
('/static/images/photo_11.jpeg', 'Portrait d Oppenheimer', 19, 26),
('/static/images/photo_12.jpeg', 'Walter White', 1, 32),
('/static/images/photo_13.jpeg', 'Eleven et ses amis', 3, 37),
('/static/images/photo_14.jpeg', 'Baby Yoda', 5, 41),
('/static/images/photo_15.jpeg', 'L Empire contre-attaque', 1, 3),
('/static/images/photo_16.jpg', 'Le Retour du Jedi', 1, 4),
('/static/images/photo_17.jpeg', 'Game of Thrones S2', 2, 6),
('/static/images/photo_18.jpeg', 'Brad Pitt et Edward Norton', 4, 9),
('/static/images/photo_19.jpeg', 'Prison Shawshank', 6, 12),
('/static/images/photo_20.jpeg', 'Forrest et sa boîte de chocolats', 7, 13),
('/static/images/photo_21.jpeg', 'La famille Corleone', 8, 14),
('/static/images/photo_22.jpeg', 'Ray Liotta Goodfellas', 9, 15),
('/static/images/photo_23.jpeg', 'Les 7 péchés capitaux', 10, 16),
('/static/images/photo_24.jpeg', 'Hannibal Lecter', 11, 17),
('/static/images/photo_25.jpeg', 'Officer K dans la ville', 12, 18),
('/static/images/photo_26.jpeg', 'Dune Partie Deux', 13, 20),
('/static/images/photo_27.jpeg', 'Thanos et les pierres', 14, 22),
('/static/images/photo_28.jpeg', 'Tony Stark premier armure', 15, 23),
('/static/images/photo_29.jpeg', 'Thor et Mjolnir', 16, 24),
('/static/images/photo_30.jpeg', 'Leonardo DiCaprio Wall Street', 17, 27),
('/static/images/photo_31.jpeg', 'Jack et Rose sur le Titanic', 18, 28),
('/static/images/photo_32.jpeg', 'La Communauté de l Anneau', 19, 29),
('/static/images/photo_33.jpeg', 'Les Deux Tours', 20, 30),
('/static/images/photo_34.jpeg', 'Le Retour du Roi', 1, 31),
('/static/images/photo_35.jpeg', 'Breaking Bad S2', 2, 33),
('/static/images/photo_36.jpeg', 'Breaking Bad S3', 3, 34),
('/static/images/photo_37.jpeg', 'Breaking Bad S4', 4, 35),
('/static/images/photo_38.jpeg', 'Breaking Bad S5 finale', 5, 36),
('/static/images/photo_39.jpeg', 'Stranger Things S2 Upside Down', 6, 38),
('/static/images/photo_40.jpeg', 'Stranger Things S3 été 1985', 7, 39),
('/static/images/photo_41.jpeg', 'Stranger Things S4 Vecna', 8, 40),
('/static/images/photo_42.jpeg', 'Mandalorian S2 aventures', 9, 42),
('/static/images/photo_43.jpeg', 'The Crown Elizabeth II', 10, 43),
('/static/images/photo_44.jpeg', 'The Crown années 60', 11, 44),
('/static/images/photo_45.jpeg', 'Peaky Blinders gang Birmingham', 12, 45),
('/static/images/photo_46.jpeg', 'Peaky Blinders S2 expansion', 13, 46),
('/static/images/photo_47.jpeg', 'Geralt et son épée', 14, 47),
('/static/images/photo_48.jpeg', 'The Witcher S2 Ciri', 15, 48),
('/static/images/photo_49.jpeg', 'House of the Dragon Targaryen', 16, 49),
('/static/images/photo_50.jpeg', 'Dragons en guerre', 17, 50);

-- ═══════════════════════════════════════════════════════════
--                         FAVORIS
-- ═══════════════════════════════════════════════════════════

INSERT INTO favoris VALUES
-- User 1
(1, 1, '2024-01-10'),  -- Inception
(1, 2, '2024-01-10'),  -- Star Wars IV
(1, 7, '2024-01-11'),  -- Dark Knight
(1, 10, '2024-01-12'), -- Matrix
(1, 26, '2024-01-13'), -- Oppenheimer
-- User 2
(2, 5, '2024-01-11'),  -- GoT S1
(2, 6, '2024-01-14'),  -- GoT S2
(2, 8, '2024-01-15'),  -- Pulp Fiction
(2, 32, '2024-01-16'), -- Breaking Bad S1
-- User 3
(3, 2, '2024-01-17'),  -- Star Wars IV
(3, 3, '2024-01-18'),  -- Star Wars V
(3, 4, '2024-01-19'),  -- Star Wars VI
(3, 41, '2024-01-20'), -- Mandalorian S1
-- User 4
(4, 2, '2024-01-12'),  -- Star Wars IV
(4, 21, '2024-01-21'), -- Avengers Endgame
(4, 22, '2024-01-22'), -- Avengers Infinity War
(4, 23, '2024-01-23'), -- Iron Man
-- User 5
(5, 1, '2024-01-13'),  -- Inception
(5, 11, '2024-01-24'), -- Interstellar
(5, 19, '2024-01-25'), -- Dune 1
(5, 20, '2024-01-26'), -- Dune 2
-- User 6
(6, 9, '2024-01-27'),  -- Fight Club
(6, 16, '2024-01-28'), -- Se7en
(6, 18, '2024-01-29'), -- Blade Runner 2049
-- User 7
(7, 12, '2024-01-30'), -- Shawshank
(7, 13, '2024-02-01'), -- Forrest Gump
(7, 14, '2024-02-02'), -- Godfather
-- User 8
(8, 37, '2024-02-03'), -- Stranger Things S1
(8, 38, '2024-02-04'), -- Stranger Things S2
(8, 39, '2024-02-05'), -- Stranger Things S3
(8, 40, '2024-02-06'), -- Stranger Things S4
-- User 9
(9, 10, '2024-02-07'), -- Matrix
(9, 18, '2024-02-08'), -- Blade Runner 2049
(9, 19, '2024-02-09'), -- Dune 1
-- User 10
(10, 25, '2024-02-10'), -- Barbie
(10, 27, '2024-02-11'), -- Wolf of Wall Street
(10, 28, '2024-02-12'), -- Titanic
-- User 11
(11, 29, '2024-02-13'), -- LOTR 1
(11, 30, '2024-02-14'), -- LOTR 2
(11, 31, '2024-02-15'), -- LOTR 3
-- User 12
(12, 45, '2024-02-16'), -- Peaky Blinders S1
(12, 46, '2024-02-17'), -- Peaky Blinders S2
-- User 13
(13, 49, '2024-02-18'), -- House of the Dragon S1
(13, 50, '2024-02-19'), -- House of the Dragon S2
(13, 5, '2024-02-20'),  -- GoT S1
-- User 14
(14, 21, '2024-02-21'), -- Avengers Endgame
(14, 23, '2024-02-22'), -- Iron Man
(14, 24, '2024-02-23'), -- Thor
-- User 15
(15, 7, '2024-02-24'),  -- Dark Knight
(15, 1, '2024-02-25'),  -- Inception
(15, 26, '2024-02-26'); -- Oppenheimer

-- ═══════════════════════════════════════════════════════════
--                    LIENS ENTRE OEUVRES
-- ═══════════════════════════════════════════════════════════

INSERT INTO lien VALUES
-- Star Wars trilogie
(2, 3, 'suite'),
(3, 4, 'suite'),
-- Game of Thrones
(5, 6, 'suite'),
-- Dune
(19, 20, 'suite'),
-- Avengers
(22, 21, 'suite'),
(23, 22, 'préquel'),
-- Breaking Bad
(32, 33, 'suite'),
(33, 34, 'suite'),
(34, 35, 'suite'),
(35, 36, 'suite'),
-- Stranger Things
(37, 38, 'suite'),
(38, 39, 'suite'),
(39, 40, 'suite'),
-- Mandalorian
(41, 42, 'suite'),
-- The Crown
(43, 44, 'suite'),
-- Peaky Blinders
(45, 46, 'suite'),
-- The Witcher
(47, 48, 'suite'),
-- House of the Dragon
(49, 50, 'suite'),
(5, 49, 'préquel'),
-- LOTR
(29, 30, 'suite'),
(30, 31, 'suite'),
-- Nolan films
(1, 7, 'même réalisateur'),
(1, 11, 'même réalisateur'),
(7, 11, 'même réalisateur'),
-- Villeneuve films
(18, 19, 'même réalisateur'),
(19, 20, 'même réalisateur');

-- ═══════════════════════════════════════════════════════════
--                         ÉPISODES
-- ═══════════════════════════════════════════════════════════

INSERT INTO episode (titre, num_ep, synopsie, id_oeuvre) VALUES
-- Game of Thrones S1 (id_oeuvre: 5)
('Winter Is Coming', 'S01E01', 'Ned Stark accepte de devenir Main du Roi', 5),
('The Kingsroad', 'S01E02', 'Voyage vers Port-Réal', 5),
('Lord Snow', 'S01E03', 'Jon Snow rejoint la Garde de Nuit', 5),
('Cripples, Bastards, and Broken Things', 'S01E04', 'Bran fait des rêves étranges', 5),
('The Wolf and the Lion', 'S01E05', 'Tensions entre Stark et Lannister', 5),
('A Golden Crown', 'S01E06', 'Viserys reçoit sa couronne d or', 5),
('You Win or You Die', 'S01E07', 'Ned découvre la vérité sur les Lannister', 5),
('The Pointy End', 'S01E08', 'Guerre entre les maisons', 5),
('Baelor', 'S01E09', 'Ned Stark face à son destin', 5),
('Fire and Blood', 'S01E10', 'Naissance des dragons', 5),
-- Game of Thrones S2 (id_oeuvre: 6)
('The North Remembers', 'S02E01', 'Début de la guerre des Cinq Rois', 6),
('The Night Lands', 'S02E02', 'Arya sur la route', 6),
('What Is Dead May Never Die', 'S02E03', 'Theon retourne aux îles de Fer', 6),
('Garden of Bones', 'S02E04', 'Horreurs de la guerre', 6),
('The Ghost of Harrenhal', 'S02E05', 'Renly assassiné', 6),
('The Old Gods and the New', 'S02E06', 'Theon prend Winterfell', 6),
('A Man Without Honor', 'S02E07', 'Jaime prisonnier', 6),
('The Prince of Winterfell', 'S02E08', 'Préparatifs de bataille', 6),
('Blackwater', 'S02E09', 'Bataille de la Néra', 6),
('Valar Morghulis', 'S02E10', 'Tous les hommes doivent mourir', 6),
-- Breaking Bad S1 (id_oeuvre: 32)
('Pilot', 'S01E01', 'Walter White diagnostiqué d un cancer', 32),
('Cat''s in the Bag', 'S01E02', 'Premier meurtre', 32),
('And the Bag''s in the River', 'S01E03', 'Walter face à un dilemme', 32),
('Cancer Man', 'S01E04', 'Walter annonce sa maladie', 32),
('Gray Matter', 'S01E05', 'Walter refuse l aide', 32),
('Crazy Handful of Nothin''', 'S01E06', 'Walter rencontre Tuco', 32),
('A No-Rough-Stuff-Type Deal', 'S01E07', 'Premier gros deal', 32),
-- Breaking Bad S2 (id_oeuvre: 33)
('Seven Thirty-Seven', 'S02E01', 'Confrontation avec Tuco', 33),
('Grilled', 'S02E02', 'Combat final contre Tuco', 33),
('Bit by a Dead Bee', 'S02E03', 'Retrouver la normalité', 33),
('Down', 'S02E04', 'Hank traumatisé', 33),
('Breakage', 'S02E05', 'Expansion du territoire', 33),
('Peekaboo', 'S02E06', 'Jesse face aux junkies', 33),
-- Stranger Things S1 (id_oeuvre: 37)
('Chapter One: The Vanishing of Will Byers', 'S01E01', 'Will disparaît mystérieusement', 37),
('Chapter Two: The Weirdo on Maple Street', 'S01E02', 'Découverte d Eleven', 37),
('Chapter Three: Holly, Jolly', 'S01E03', 'Recherches dans l Upside Down', 37),
('Chapter Four: The Body', 'S01E04', 'Fausses funérailles de Will', 37),
('Chapter Five: The Flea and the Acrobat', 'S01E05', 'Plan pour sauver Will', 37),
('Chapter Six: The Monster', 'S01E06', 'Le Demogorgon attaque', 37),
('Chapter Seven: The Bathtub', 'S01E07', 'Eleven cherche Will', 37),
('Chapter Eight: The Upside Down', 'S01E08', 'Mission de sauvetage finale', 37),
-- Stranger Things S2 (id_oeuvre: 38)
('Chapter One: MADMAX', 'S02E01', 'Nouvelle menace se profile', 38),
('Chapter Two: Trick or Treat, Freak', 'S02E02', 'Halloween à Hawkins', 38),
('Chapter Three: The Pollywog', 'S02E03', 'Dustin trouve un étrange animal', 38),
('Chapter Four: Will the Wise', 'S02E04', 'Will a des visions', 38),
('Chapter Five: Dig Dug', 'S02E05', 'Tunnels sous Hawkins', 38),
('Chapter Six: The Spy', 'S02E06', 'Will possédé', 38),
('Chapter Seven: The Lost Sister', 'S02E07', 'Passé d Eleven révélé', 38),
('Chapter Eight: The Mind Flayer', 'S02E08', 'Véritable menace identifiée', 38),
('Chapter Nine: The Gate', 'S02E09', 'Bataille finale', 38),
-- The Mandalorian S1 (id_oeuvre: 41)
('Chapter 1: The Mandalorian', 'S01E01', 'Mando reçoit une nouvelle mission', 41),
('Chapter 2: The Child', 'S01E02', 'Découverte de Baby Yoda', 41),
('Chapter 3: The Sin', 'S01E03', 'Dilemme moral de Mando', 41),
('Chapter 4: Sanctuary', 'S01E04', 'Village attaqué par des raiders', 41),
('Chapter 5: The Gunslinger', 'S01E05', 'Chasseur de primes sur Tatooine', 41),
('Chapter 6: The Prisoner', 'S01E06', 'Mission de libération', 41),
('Chapter 7: The Reckoning', 'S01E07', 'Confrontation avec Moff Gideon', 41),
('Chapter 8: Redemption', 'S01E08', 'Bataille finale saison 1', 41),
-- Peaky Blinders S1 (id_oeuvre: 45)
('Episode 1', 'S01E01', 'Retour de la guerre, gang des Peaky Blinders', 45),
('Episode 2', 'S01E02', 'Armes volées recherchées', 45),
('Episode 3', 'S01E03', 'Thomas face à l inspecteur Campbell', 45),
('Episode 4', 'S01E04', 'Expansion du gang', 45),
('Episode 5', 'S01E05', 'Alliance avec les gitans', 45),
('Episode 6', 'S01E06', 'Confrontation finale', 45),
-- House of the Dragon S1 (id_oeuvre: 49)
('The Heirs of the Dragon', 'S01E01', 'Succession Targaryen en question', 49),
('The Rogue Prince', 'S01E02', 'Daemon exilé', 49),
('Second of His Name', 'S01E03', 'Viserys choisit sa Main', 49),
('King of the Narrow Sea', 'S01E04', 'Rhaenyra grandit', 49),
('We Light the Way', 'S01E05', 'Mariage royal', 49),
('The Princess and the Queen', 'S01E06', 'Tensions familiales', 49),
('Driftmark', 'S01E07', 'Funérailles et révélations', 49),
('The Lord of the Tides', 'S01E08', 'Question de succession', 49),
('The Green Council', 'S01E09', 'Coup d État', 49),
('The Black Queen', 'S01E10', 'Début de la guerre civile', 49);
